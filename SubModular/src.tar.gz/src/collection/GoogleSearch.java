/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package collection;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import de.l3s.boilerpipe.BoilerpipeProcessingException;
import de.l3s.boilerpipe.extractors.ArticleExtractor;
import de.l3s.boilerpipe.extractors.DefaultExtractor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.apache.lucene.analysis.snowball.SnowballAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Version;
import org.apache.tika.Tika;

/**
 *
 * @author biplab
 */
public class GoogleSearch 
{
    public List<String> getUrls(String query) throws MalformedURLException, IOException, BoilerpipeProcessingException
    {
        List<String> list=new LinkedList<String>();
        URL url = new URL("http://ajax.googleapis.com/ajax/services/search/web?v=1.0&q="+query);
        URLConnection conn = url.openConnection();
        conn.addRequestProperty("User-Agent", "Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.0)");
        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String jsonText="";
        String input;
	while(true)
        {
            input=br.readLine();
            if(input==null)
            {
                break;
            }
            jsonText=jsonText+"\n"+input;
        }
        JsonElement root = new JsonParser().parse(jsonText);
        JsonObject jsonObject;
        jsonObject = root.getAsJsonObject().get("responseData").getAsJsonObject();
        JsonArray jsonArray=jsonObject.get("results").getAsJsonArray();
        for(JsonElement jsonElement:jsonArray)
        {
            list.add(jsonElement.getAsJsonObject().get("url").getAsString());
        }
       
        //System.out.println(list);
        
        return list;
    }
    public List<String> getContents(List<String> urls) throws MalformedURLException, IOException, BoilerpipeProcessingException
    {
        List<String> list=new LinkedList<String>();
        Tika tika=new Tika();
        for(String url:urls)
        {
            URL urlAdd = new URL(url);
            System.out.println(tika.detect(urlAdd));
            URLConnection conn = urlAdd.openConnection();
            conn.addRequestProperty("User-Agent", "Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.0)");
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String htmlText="";
            String input;
            while(true)
            {
                input=br.readLine();
                if(input==null)
                {
                    break;
                }
                htmlText=htmlText+"\n"+input;
            }
            String text = ArticleExtractor.INSTANCE.getText(htmlText);
            list.add(text.replaceAll("\\[[0-9]+\\]",""));
        }
        
        return list;
    }
    public List<String> getParagraphsRanked(List<String> contents) throws IOException, ParseException
    {
        StandardAnalyzer analyzer=new StandardAnalyzer(Version.LUCENE_40);
        Directory index = new RAMDirectory();
        IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_40,analyzer);
        IndexWriter w = new IndexWriter(index, config);
        for(String content:contents)
        {
            String[] paragraphs=content.split("\n");
            for(String paragraph:paragraphs)
            {
                Document doc = new Document();
                doc.add(new TextField("content",paragraph, Field.Store.YES));
                w.addDocument(doc);
            }
            
        }
        w.close();
        IndexReader reader = DirectoryReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopScoreDocCollector collector = TopScoreDocCollector.create(10, true);
        String querystr="What is capital of India";
        Query q = new QueryParser(Version.LUCENE_40, "content", analyzer).parse(querystr);
        searcher.search(q, collector);
        ScoreDoc[] hits = collector.topDocs().scoreDocs;
        for(int i=0;i<hits.length;++i) 
        {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            System.out.println((i + 1) + ". "+d.get("content"));
        
        }
        return null;
    }
    
}
